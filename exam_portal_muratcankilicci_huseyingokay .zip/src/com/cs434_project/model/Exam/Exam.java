package com.cs434_project.model.Exam;

import com.cs434_project.model.Question.Question;

import java.util.List;

public class Exam {
    private List<Question> questionList;
}
