package com.cs434_project.model.Admin;

public class Admin {
    private final int adminId;
    private final String userName;
    private final String password;

    public Admin(int adminId, String userName, String password) {
        this.adminId = adminId;
        this.password = password;
        this.userName = userName;
    }

    public void createExam(){

    }
}
