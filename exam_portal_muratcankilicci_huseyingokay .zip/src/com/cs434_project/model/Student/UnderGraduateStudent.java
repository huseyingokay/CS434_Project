package com.cs434_project.model.Student;

public class UnderGraduateStudent extends Student{
    public UnderGraduateStudent(int studentId, String studentName, String password) {
        super(studentId, studentName, password);
    }
}
