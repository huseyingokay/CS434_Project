package com.cs434_project.model.Student;

public class GraduateStudent extends Student{
    public GraduateStudent(int studentId, String studentName, String password) {
        super(studentId, studentName, password);
    }
}
